import json
from flask import render_template_string

def render_admin_panel(username):
    bots = json.load(open("bots.json"))

    html = "<h2>لوحة تحكم الأدمن 🔧</h2>"
    html += f"<p>مرحبًا {username} ✅🛠️</p><hr>"

    for user, files in bots.items():
        html += f"<h4>👤 {user}</h4><ul>"
        for f in files:
            html += f"<li>{f} — <a href='/uploads/{'/'.join(f.split('/')[1:])}' download>تحميل</a></li>"
        html += "</ul><hr>"

    return render_template_string(html)