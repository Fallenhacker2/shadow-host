import os
from flask import redirect
import json

def handle_upload(request, username):
    file = request.files['file']
    if not file.filename.endswith(".py"):
        return "❌ يجب رفع ملف Python فقط"

    user_dir = f"uploads/{username}"
    os.makedirs(user_dir, exist_ok=True)
    filepath = os.path.join(user_dir, file.filename)
    file.save(filepath)

    bots = load_bots()
    bots[username] = bots.get(username, []) + [filepath]
    save_bots(bots)

    return redirect('/')

def load_bots():
    try:
        with open("bots.json", "r") as f:
            return json.load(f)
    except:
        return {}

def save_bots(bots):
    with open("bots.json", "w") as f:
        json.dump(bots, f, indent=2)