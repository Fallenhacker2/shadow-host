import json
from flask import request, session, redirect, render_template_string
import re

def load_users():
    try:
        with open("users.json", "r") as f:
            return json.load(f)
    except:
        return {}

def save_users(users):
    with open("users.json", "w") as f:
        json.dump(users, f, indent=2)

def is_valid_username(name):
    return re.match(r'^[a-zA-Z0-9_]+$', name)

def register_user(request):
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if not is_valid_username(username):
            return "❌ اسم المستخدم غير صالح"
        users = load_users()
        if username in users:
            return "❌ المستخدم موجود بالفعل"
        users[username] = {"password": password, "admin": False}
        save_users(users)
        session['username'] = username
        return redirect('/')
    return render_template_string(open("templates/register.html").read())

def login_user(request):
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        users = load_users()
        if username in users and users[username]['password'] == password:
            session['username'] = username
            return redirect('/')
        return "❌ معلومات الدخول خاطئة"
    return render_template_string(open("templates/login.html").read())

def login_required(func):
    def wrapper(*args, **kwargs):
        if 'username' not in session:
            return redirect('/login')
        return func(*args, **kwargs)
    wrapper.__name__ = func.__name__
    return wrapper

def check_admin(username):
    users = load_users()
    return users.get(username, {}).get("admin", False)