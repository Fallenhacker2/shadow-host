import json
from flask import render_template_string

def render_user_panel(username):
    bots = json.load(open("bots.json"))
    files = bots.get(username, [])

    html = f"<h2>مرحبًا {username} 🤖</h2><hr>"
    html += "<ul>"
    for f in files:
        html += f"<li>{f} — <a href='/uploads/{'/'.join(f.split('/')[1:])}' download>تحميل</a></li>"
    html += "</ul><hr><form action='/upload' method='post' enctype='multipart/form-data'><input type='file' name='file'><input type='submit' value='رفع'></form>"
    return render_template_string(html)