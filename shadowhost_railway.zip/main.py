from flask import Flask, request, redirect, render_template, session, send_from_directory
from uploader import handle_upload
from auth import login_required, check_admin
from admin_panel import render_admin_panel
from user_panel import render_user_panel
import os

app = Flask(__name__)
app.secret_key = 'shadow-core-railway'

@app.route('/')
def index():
    if 'username' in session:
        if check_admin(session['username']):
            return render_admin_panel(session['username'])
        return render_user_panel(session['username'])
    return redirect('/login')

@app.route('/login', methods=['GET', 'POST'])
def login():
    from auth import login_user
    return login_user(request)

@app.route('/register', methods=['GET', 'POST'])
def register():
    from auth import register_user
    return register_user(request)

@app.route('/upload', methods=['POST'])
@login_required
def upload():
    return handle_upload(request, session['username'])

@app.route('/uploads/<path:filename>')
def download_file(filename):
    return send_from_directory('uploads', filename, as_attachment=True)

if __name__ == '__main__':
    os.system("python3 bot_notifier.py &")
    app.run(host='0.0.0.0', port=8080)