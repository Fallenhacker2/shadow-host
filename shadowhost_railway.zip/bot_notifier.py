import json
import time
import requests

BOT_TOKEN = "8196268893:AAGGEMC8IbHaQtlrMkj-eEcDYa2HWaYQr_E"
ADMIN_ID = "7700185632"

def notify_admin(username, filepath):
    message = f"👤 مستخدم جديد رفع بوت\n• الاسم: {username}\n• الملف: {filepath}"
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    requests.post(url, data={"chat_id": ADMIN_ID, "text": message})

def watch_bots():
    cache = {}
    while True:
        try:
            with open("bots.json") as f:
                bots = json.load(f)
            for user, files in bots.items():
                if user not in cache:
                    cache[user] = set()
                for f in files:
                    if f not in cache[user]:
                        notify_admin(user, f)
                        cache[user].add(f)
        except Exception as e:
            print("Error:", e)
        time.sleep(10)

if __name__ == "__main__":
    watch_bots()